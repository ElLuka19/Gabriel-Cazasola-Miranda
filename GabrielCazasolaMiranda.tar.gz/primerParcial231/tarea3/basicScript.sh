#!/bin/bash
echo "Bienvenido al scrip del examen, ingresa tu nombre"
read nombre
echo "Saludos"  nombre 
mkdir ubicaciones 
cd ubicaciones
pwd >> ubicaciones 
date >> HoraTarea3
cd -
ls -l 
echo "se a finalizado el scrip" 
